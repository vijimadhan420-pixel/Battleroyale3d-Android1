# BattleRoyale3DAndroid — Offline 3D Shooting Prototype

Android native Java + OpenGL ES 2.0 அடிப்படையிலான offline 3D shooting prototype. வெளிப்புற library அல்லது இணைய இணைப்பு தேவையில்லை.

## இப்போது உள்ள அம்சங்கள்
- Landscape full-screen Android game
- OpenGL ES 2.0 மூலம் 3D-style island, road markings, buildings, windows, trees, cover rocks/crates
- Third-person player avatar மற்றும் aim-ஐப் பின்பற்றும் gun/crosshair
- 9 enemy bots: அருகில் வருதல், சுற்றி நகர்தல், அருகில் வந்தால் player HP குறைத்தல்
- Aim direction அடிப்படையிலான shooting, bot HP, kills, ammo
- HP / ammo / enemies / kills HUD
- FIRE, RELOAD, match முடிந்தால் restart
- Android API 23+ ஆதரவு; compileSdk 35

> இது playable prototype; PUBG அளவிலான முழுமையான 3D game அல்ல. இதில் உண்மையான 3D mesh/texture assets, skeletal animation, sound, inventory, zone shrink, vehicles, online multiplayer அல்லது server இல்லை. Bots-ன் pathfinding எளிமையானது.

## Android APK build செய்வது
### Android Studio வழி
1. கணினியில் Android Studio நிறுவவும்.
2. ZIP-ஐ extract செய்து `BattleRoyale3DAndroid` folder-ஐ Android Studio-வில் **Open** செய்யவும்.
3. Android SDK Platform 35 நிறுவவும்; JDK 17 தேர்ந்தெடுக்கவும்.
4. Gradle Sync முடியும் வரை காத்திருக்கவும்.
5. **Build → Build Bundle(s) / APK(s) → Build APK(s)** தேர்வு செய்யவும்.
6. Debug APK இங்கு உருவாகும்: `app/build/outputs/apk/debug/app-debug.apk`
7. APK-ஐ Android மொபைலுக்கு மாற்றி நிறுவவும். Android கேட்டால் அந்த file manager-க்கு “Install unknown apps” அனுமதி கொடுக்கவும்.

### Command line
Android SDK மற்றும் Gradle wrapper கிடைத்தால் project root-ல்:
```bash
gradle assembleDebug
```
அல்லது Android Studio-வின் Gradle task `:app:assembleDebug` இயக்கவும். இந்த ZIP-ல் Gradle wrapper சேர்க்கப்படவில்லை.

## Controls (Landscape)
- **இடது பக்கத்தை drag**: நகர்வு
- **வலது பக்கத்தை drag**: aim / camera-facing direction மாற்றம்
- **FIRE**: சுடுதல்; bot-ன் திசையில் crosshair align ஆக வேண்டும்
- **RELOAD**: ammo-வை மீண்டும் நிரப்புதல்
- HP 0 ஆனால் அல்லது எல்லா bots-ஐ வென்றால், **FIRE** தட்டி புதிய match தொடங்கவும்

## Build நிலை
இந்த வெளியீட்டில் source code மேம்படுத்தப்பட்டுள்ளது; Android SDK/Gradle build tools இந்த சூழலில் கிடைக்காததால் APK build செய்து device-ல் சோதிக்கப்பட்டதாகக் கூற முடியாது. Android Studio-வில் build செய்யும்போது வரும் error-ஐ பகிர்ந்தால் அதன்படி சரிசெய்யலாம்.
