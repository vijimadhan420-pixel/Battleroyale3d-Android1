# மொபைலில் மட்டும் APK உருவாக்குவது (தமிழ்)

இந்த project-ல் GitHub Actions workflow சேர்க்கப்பட்டுள்ளது. Android Studio தேவையில்லை; GitHub-ன் cloud computer APK build செய்யும்.

## படிகள்
1. GitHub account இல்லையெனில் github.com-ல் account உருவாக்கவும்.
2. GitHub-ல் **New repository** உருவாக்கவும். பெயர் `BattleRoyale3DAndroid`; Public அல்லது Private தேர்வு செய்து Create repository அழுத்தவும்.
3. ZIP-ஐ மொபைல் File Manager-ல் extract செய்யவும்.
4. Extract செய்யப்பட்ட `BattleRoyale3DAndroid` folder-க்குள் உள்ள கோப்புகள்/கோப்புறைகளை repository-க்கு upload செய்யவும். `settings.gradle`, `build.gradle`, `app` folder, `.github/workflows/android-apk.yml` ஆகியவை repository root-இல் இருக்க வேண்டும்; இன்னொரு `BattleRoyale3DAndroid` folder உள்ளே nested ஆகிவிடக்கூடாது.
5. GitHub repository-ல் **Actions** tab திறந்து **Build Android APK** workflow தேர்வு செய்து **Run workflow** அழுத்தவும். முதல் முறை GitHub Actions enable செய்ய வேண்டியிருக்கலாம்.
6. Build முடிந்ததும் workflow run-ஐத் திறந்து **Artifacts** பகுதியில் `BattleRoyale3DAndroid-debug-apk` பதிவிறக்கவும்.
7. ZIP artifact-ஐ extract செய்து `app-debug.apk`-ஐத் திறந்து நிறுவவும். Android கேட்டால் அந்த browser/file manager-க்கு “Install unknown apps” அனுமதி அளிக்கவும்.

## கவனிக்கவும்
- Build முடியும் முன் GitHub Actions logs-ல் error வந்தால், error text-ஐ அனுப்பவும்; அதைச் சரிசெய்ய உதவுகிறேன்.
- இது debug APK. இது prototype; PUBG அளவிலான முழுமையான game அல்லது online multiplayer அல்ல.
