package com.example.battleroyale3d;

import android.app.Activity;
import android.os.Bundle;
import android.opengl.GLSurfaceView;
import android.view.*;
import android.content.Context;
import android.graphics.*;
import android.widget.*;
import android.view.Gravity;
import java.util.*;
import java.nio.*;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import android.opengl.GLES20;
import android.opengl.Matrix;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
        GameLayout root = new GameLayout(this);
        setContentView(root);
    }

    static class GameLayout extends FrameLayout {
        GameRenderer renderer;
        TextView hud;
        long lastHud = 0;
        GameLayout(Context c) {
            super(c);
            GLSurfaceView gl = new GLSurfaceView(c);
            gl.setEGLContextClientVersion(2);
            renderer = new GameRenderer();
            gl.setRenderer(renderer);
            gl.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
            addView(gl, new FrameLayout.LayoutParams(-1,-1));
            hud = new TextView(c);
            hud.setTextColor(Color.WHITE); hud.setTextSize(17); hud.setTypeface(Typeface.DEFAULT_BOLD);
            hud.setShadowLayer(4,2,2,Color.BLACK); hud.setPadding(24,14,16,8);
            addView(hud, new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT));
            TextView shoot = new TextView(c);
            shoot.setText("FIRE"); shoot.setTextColor(Color.WHITE); shoot.setTextSize(18);
            shoot.setGravity(Gravity.CENTER); shoot.setTypeface(Typeface.DEFAULT_BOLD);
            shoot.setBackgroundColor(0xAA9C302B);
            FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(124,124,Gravity.RIGHT|Gravity.BOTTOM);
            sp.setMargins(0,0,34,30); addView(shoot,sp);
            shoot.setOnTouchListener((v,e)->{
                if(e.getAction()==MotionEvent.ACTION_DOWN) renderer.fire();
                return true;
            });
            TextView reload = new TextView(c);
            reload.setText("RELOAD"); reload.setTextColor(Color.WHITE); reload.setTextSize(14);
            reload.setGravity(Gravity.CENTER); reload.setTypeface(Typeface.DEFAULT_BOLD);
            reload.setBackgroundColor(0xAA34495E);
            FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(104,64,Gravity.RIGHT|Gravity.BOTTOM);
            rp.setMargins(0,0,48,168); addView(reload,rp);
            reload.setOnClickListener(v -> renderer.reload());
            TextView help = new TextView(c);
            help.setText("MOVE: drag left side     AIM/FIRE: tap FIRE");
            help.setTextColor(0xFFE7E7E7); help.setTextSize(13);
            FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
            hp.setMargins(0,0,0,12); addView(help,hp);
            gl.setOnTouchListener((v,e)->{
                float w=v.getWidth();
                if(e.getX()<w*.48f) {
                    if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE) {
                        renderer.setMove((e.getX()-w*.23f)/(w*.23f), (e.getY()-v.getHeight()*.68f)/(v.getHeight()*.32f));
                    }
                    if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL) renderer.setMove(0,0);
                } else if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE) {
                    renderer.aimAt((e.getX()/w-.74f)/.26f);
                }
                return true;
            });
            postHud();
        }
        void postHud() {
            postDelayed(new Runnable(){ public void run(){
                hud.setText(renderer.getHud());
                postHud();
            }},250);
        }
    }

    static class Bot {
        float x,z; int hp=2; float phase;
        Bot(float a,float b,float p){x=a;z=b;phase=p;}
    }

    static class GameRenderer implements GLSurfaceView.Renderer {
        int program, posHandle, colorHandle, mvpHandle;
        FloatBuffer cubeBuffer;
        final float[] projection=new float[16], view=new float[16], model=new float[16], mvp=new float[16];
        float px=0,pz=4, moveX=0,moveY=0, yaw=0;
        int kills=0, ammo=60, hp=100;
        final int magazineSize=30;
        long lastShot=0, lastReload=0;
        boolean over=false, won=false;
        long start=System.currentTimeMillis();
        ArrayList<Bot> bots=new ArrayList<>();
        Random rnd=new Random(12);
        final float[] cube={
          -0.5f,-0.5f, 0.5f,  0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f,
          -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0.5f,-0.5f,-0.5f,
          -0.5f,0.5f,-0.5f, -0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f,
          -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f,
          0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f, 0.5f,-0.5f,0.5f,
          -0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f
        };
        String vertex="attribute vec3 aPos; uniform mat4 uMVP; void main(){ gl_Position=uMVP*vec4(aPos,1.0); }";
        String fragment="precision mediump float; uniform vec4 uColor; void main(){ gl_FragColor=uColor; }";
        @Override public void onSurfaceCreated(GL10 gl,EGLConfig cfg) {
            GLES20.glClearColor(0.42f,0.68f,0.82f,1);
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);
            program=link(vertex,fragment);
            posHandle=GLES20.glGetAttribLocation(program,"aPos");
            colorHandle=GLES20.glGetUniformLocation(program,"uColor");
            mvpHandle=GLES20.glGetUniformLocation(program,"uMVP");
            ByteBuffer bb=ByteBuffer.allocateDirect(cube.length*4).order(ByteOrder.nativeOrder());
            cubeBuffer=bb.asFloatBuffer(); cubeBuffer.put(cube).position(0);
            for(int i=0;i<9;i++) bots.add(new Bot(rnd.nextFloat()*26-13,rnd.nextFloat()*-26-4,rnd.nextFloat()*6.28f));
        }
        int link(String vs,String fs) {
            int v=GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER); GLES20.glShaderSource(v,vs); GLES20.glCompileShader(v);
            int f=GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER); GLES20.glShaderSource(f,fs); GLES20.glCompileShader(f);
            int p=GLES20.glCreateProgram(); GLES20.glAttachShader(p,v); GLES20.glAttachShader(p,f); GLES20.glLinkProgram(p); return p;
        }
        @Override public void onSurfaceChanged(GL10 gl,int w,int h) {
            GLES20.glViewport(0,0,w,h); Matrix.perspectiveM(projection,0,62,(float)w/Math.max(1,h),.1f,150f);
        }
        void drawBox(float x,float y,float z,float sx,float sy,float sz,float r,float g,float b) {
            Matrix.setIdentityM(model,0); Matrix.translateM(model,0,x,y,z); Matrix.scaleM(model,0,sx,sy,sz);
            Matrix.multiplyMM(mvp,0,view,0,model,0); float[] out=new float[16];
            Matrix.multiplyMM(out,0,projection,0,mvp,0);
            GLES20.glUniformMatrix4fv(mvpHandle,1,false,out,0);
            GLES20.glUniform4f(colorHandle,r,g,b,1);
            cubeBuffer.position(0); GLES20.glVertexAttribPointer(posHandle,3,GLES20.GL_FLOAT,false,0,cubeBuffer);
            GLES20.glEnableVertexAttribArray(posHandle); GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN,0,4);
            cubeBuffer.position(12); GLES20.glVertexAttribPointer(posHandle,3,GLES20.GL_FLOAT,false,0,cubeBuffer);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN,0,4);
            cubeBuffer.position(24); GLES20.glVertexAttribPointer(posHandle,3,GLES20.GL_FLOAT,false,0,cubeBuffer);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN,0,4);
            cubeBuffer.position(36); GLES20.glVertexAttribPointer(posHandle,3,GLES20.GL_FLOAT,false,0,cubeBuffer);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN,0,4);
            cubeBuffer.position(48); GLES20.glVertexAttribPointer(posHandle,3,GLES20.GL_FLOAT,false,0,cubeBuffer);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN,0,4);
            cubeBuffer.position(60); GLES20.glVertexAttribPointer(posHandle,3,GLES20.GL_FLOAT,false,0,cubeBuffer);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN,0,4);
        }
        @Override public void onDrawFrame(GL10 gl) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
            GLES20.glUseProgram(program);
            if(!over) {
                float speed=.075f;
                px += (float)(moveX*Math.cos(yaw)-moveY*Math.sin(yaw))*speed;
                pz += (float)(moveX*Math.sin(yaw)+moveY*Math.cos(yaw))*speed;
                px=Math.max(-18,Math.min(18,px)); pz=Math.max(-28,Math.min(8,pz));
                long now=System.currentTimeMillis();
                for(Bot b:bots) {
                    float dx=px-b.x,dz=pz-b.z,dist=(float)Math.sqrt(dx*dx+dz*dz);
                    if(dist>2.0f && dist<22) { b.x+=dx/Math.max(dist,.01f)*.018f; b.z+=dz/Math.max(dist,.01f)*.018f; }
                    else if(dist>=22) { b.x+=(float)Math.sin(now*.001+b.phase)*.006f; b.z+=(float)Math.cos(now*.001+b.phase)*.006f; }
                    if(dist<10 && now%650<18) hp=Math.max(0,hp-2);
                }
                if(hp<=0 || (bots.isEmpty())) { over=true; won=bots.isEmpty(); }
            }
            Matrix.setLookAtM(view,0,px,3.4f,pz+6,px,1.1f,pz-5,0,1,0);
            // island floor
            drawBox(0,-.45f,-10,42,.5f,54,.24f,.43f,.22f);
            // boundary water/platform edges
            drawBox(0,-.65f,-10,48,.25f,60,.12f,.42f,.68f);
            // roads and lane markings
            drawBox(0,-.17f,-11,5,.08f,50,.22f,.24f,.24f);
            for(int road=-32;road<15;road+=5) drawBox(0,-.115f,road,.12f,.025f,1.7f,.88f,.78f,.32f);
            // simple buildings
            for(int i=0;i<8;i++) {
                float bx=(i%4)*8-12, bz=-(i/4)*17-6;
                drawBox(bx,.55f,bz,4,1.8f,4,.65f,.62f,.52f);
                drawBox(bx,1.65f,bz,4.2f,.25f,4.2f,.35f,.22f,.18f);
                drawBox(bx,0.35f,bz+2.05f,.7f,1.0f,.1f,.2f,.24f,.28f);
                // front windows
                drawBox(bx-1.1f,1.0f,bz+2.08f,.65f,.55f,.06f,.22f,.63f,.78f);
                drawBox(bx+1.1f,1.0f,bz+2.08f,.65f,.55f,.06f,.22f,.63f,.78f);
            }
            // scattered cover rocks and crates
            for(int i=0;i<10;i++) {
                float cx=(float)Math.sin(i*4.3)*14f, cz=-((i*9)%36)-3;
                drawBox(cx,.25f,cz,1.1f,.55f,1.0f,.36f,.38f,.34f);
            }
            // trees
            for(int i=0;i<16;i++) {
                float tx=(float)Math.sin(i*7.1)*17, tz=-((i*13)%43)-2;
                drawBox(tx,.25f,tz,.35f,1.3f,.35f,.3f,.19f,.09f);
                drawBox(tx,1.5f,tz,1.5f,1.6f,1.5f,.12f,.38f,.17f);
            }
            // enemy bots
            for(Bot b:bots) {
                drawBox(b.x,.5f,b.z,.65f,1.1f,.5f,.65f,.13f,.1f);
                drawBox(b.x,1.28f,b.z,.48f,.45f,.45f,.83f,.65f,.45f);
                drawBox(b.x,.72f,b.z-.42f,.75f,.18f,.65f,.14f,.16f,.18f);
            }
            // player avatar in blue
            drawBox(px,.55f,pz,.7f,1.15f,.55f,.1f,.3f,.82f);
            drawBox(px,1.32f,pz,.48f,.45f,.48f,.76f,.58f,.42f);
            // gun barrel follows aim direction
            float gx=px+(float)Math.sin(yaw)*.65f, gz=pz-(float)Math.cos(yaw)*.65f;
            drawBox(gx,.88f,gz,.18f,.18f,.9f,.10f,.11f,.12f);
            // crosshair marker follows aim direction
            float cx=px+(float)Math.sin(yaw)*4.0f, cz=pz-(float)Math.cos(yaw)*4.0f;
            drawBox(cx,1.15f,cz,.22f,.035f,.035f,1,.88f,.16f);
            drawBox(cx,1.15f,cz,.035f,.22f,.035f,1,.88f,.16f);
        }
        synchronized void setMove(float x,float y){ moveX=Math.max(-1,Math.min(1,x)); moveY=Math.max(-1,Math.min(1,y)); }
        synchronized void aimAt(float x){ yaw=Math.max(-1.45f,Math.min(1.45f,x*1.45f)); }
        synchronized void reload() {
            if(over) { reset(); return; }
            if(System.currentTimeMillis()-lastReload<700) return;
            ammo=magazineSize; lastReload=System.currentTimeMillis();
        }
        synchronized void fire() {
            if(over) { reset(); return; }
            long now=System.currentTimeMillis();
            if(now-lastShot<180) return;
            lastShot=now;
            if(ammo<=0) return;
            ammo--;
            Bot best=null; float bestD=100, bestAngle=.30f;
            float dirX=(float)Math.sin(yaw), dirZ=-(float)Math.cos(yaw);
            for(Bot b:bots) {
                float dx=b.x-px,dz=b.z-pz, d=(float)Math.sqrt(dx*dx+dz*dz);
                if(d<.1f || d>24) continue;
                float dot=(dx*dirX+dz*dirZ)/d;
                float angle=(float)Math.acos(Math.max(-1,Math.min(1,dot)));
                if(angle<bestAngle && d<bestD) { best=b; bestD=d; }
            }
            if(best!=null) {
                best.hp--;
                if(best.hp<=0) { bots.remove(best); kills++; }
            }
        }
        synchronized void reset() {
            px=0;pz=4;hp=100;ammo=magazineSize*2;kills=0;over=false;won=false;yaw=0;lastShot=0;bots.clear();
            for(int i=0;i<9;i++) bots.add(new Bot(rnd.nextFloat()*26-13,rnd.nextFloat()*-26-4,rnd.nextFloat()*6.28f));
        }
        synchronized String getHud() {
            if(over) return won ? "WINNER WINNER!   Kills: "+kills+"   Tap FIRE to restart" : "YOU ARE OUT   Kills: "+kills+"   Tap FIRE to restart";
            return "BATTLE ROYALE 3D   |   HP "+hp+"   |   AMMO "+ammo+"   |   ENEMIES "+bots.size()+"   |   KILLS "+kills+"\nLEFT: MOVE   RIGHT: AIM   FIRE: SHOOT";
        }
    }
}
